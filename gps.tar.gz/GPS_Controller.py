#!/usr/bin/python
from gps import *
import threading

# Initialise the Ultimate GPS Controller class
#os.system('sudo gpsd /dev/ttyAMA0 -F /var/run/gpsd.sock') #gpsd autostart enabled via command: sudo dpkg-reconfigure gpsd
class GpsController(threading.Thread):
    def __init__(self):
        threading.Thread.__init__(self)
        self.gpsd = gps(mode=WATCH_ENABLE) #starting the stream of info
        self.running = False

    def run(self):
        self.running = True
        while self.running:
            # grab EACH set of gpsd info to clear the buffer
            self.gpsd.next()

    def stopController(self):
        self.running = False

    @property
    def fix(self):
        return self.gpsd.fix

    @property
    def utc(self):
        return self.gpsd.utc

    @property
    def satellites(self):
        return self.gpsd.satellites

